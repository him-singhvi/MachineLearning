#Version 4
import os
#import psycopg2
from flask import Flask, render_template,jsonify, request, g
import pandas as pd
import numpy as np
from simple_salesforce import Salesforce, SalesforceLogin
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize
from string import punctuation
import nltk
nltk.download('stopwords')
nltk.download('punkt')
import re
import json


app = Flask(__name__)
app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY', 'XYZ')


#def connect_db():
#    return psycopg2.connect(os.environ.get('DATABASE_URL'))


#@app.before_request
#def before_request():
  #  g.db_conn = connect_db()


#@app.route('/')
#def index():
 #   cur.execute("SELECT * FROM country;")
  #  return render_template('index.html', countries=cur.fetchall())
 #      return "Hello Krsna"   
     
     
cred = [{'username':'B'}]
@app.route('/', methods=['GET'])
def index():
    return 'Test'
    


@app.route('/auth', methods=['GET', 'POST'])
def recCredential():
    inputCaseId = request.json['CaseId']
    loginData = AuthAndRetrieveData(request.json['userName'], request.json['password'], request.json['token'], request.json['isSandbox'])
    sf = loginData.authentication("Test")
    queryCase = loginData.retrieveData(sf, inputCaseId)
    df = pd.DataFrame(queryCase) 
    print('df 51-->', df)
    print('columns -->', df.columns)
    preprocessingObj = PreProcessing()
    df = preprocessingObj.preProcessing(df)  
    print("df 55----->",df.head(1))
    #input = "Issue: After the customer refreshed his sanbox he is getting the folllowing error when the user goes to the Remedyforce CMDB   Unexpected end-of-input: was expecting closing '\"\"' for name at [line:1, column:511] An unexpected error has occurred. Your solution provider has been notified. (System)"
    input = request.json['DESCRIPTION']
    print(input)
    inputMod = preprocessingObj.identifyModule(input)
    inputToken = preprocessingObj.inputTokenizing(input)
    cosinLogicObj = CosinLogic()
    
    df = cosinLogicObj.cosin(df, inputToken)
    print('columns 65-->', df.columns)
    df = cosinLogicObj.maxSimilarityLogic(df, inputMod)
    print('columns 67-->', df.columns)
    #print(df)
    
    df = df[['Id','Module', 'Similarity_Index', 'Case_Owner']]
    #print(df)
    df = df.rename(columns = {"Id": "Suggested_Case__c", "Module":"Module__c", "Similarity_Index":"Similarity_Index__c", "Case_Owner":"Case_Owner__c"}) 
    df['Case_Name__c'] = inputCaseId
    #print("DF--->",df)
    data = df.to_json(orient='records')
    data = json.loads(data)
    print("Json--->",data)
    #data = [{"Module__c":"CMDB,","Similarity_Index__c":0.87055},{"Module__c":"CMDB,","Similarity_Index__c":0.84265},{"Module__c":"Upgrade, CMDB,","Similarity_Index__c":0.70825}] 
     #      [{"Module__c":"CMDB,","Similarity_Index__c":0.87055},{"Module__c":"CMDB,","Similarity_Index__c":0.84265},{"Module__c":"Upgrade, CMDB,","Similarity_Index__c":0.70825}]
    sf.bulk.Suggested_Case__c.insert(data) 
    #sf.bulk.Suggested_Case__c.insert(df)
    return df #jsonify({'cred': c
    # reds})
    
 
class CosinLogic:
    def cosin(self, df, inputToken):
        clean = []
        for texts in df.cleaned_text:
            l1 = []
            lst = []
            text_list = word_tokenize(texts)
            sw = stopwords.words('english')
            text_set = {w for w in text_list if not w in sw} 
            rvector = inputToken.union(text_set)
            
            for w in rvector: 
                if w in inputToken: l1.append(1) # create a vector 
                else: l1.append(0) 
                if w in text_set: lst.append(1) 
                else: lst.append(0) 
            c = 0
            
            for i in range(len(rvector)): 
                c+= l1[i]*lst[i] 
            cosine = c / float((sum(l1)*sum(lst))**0.5)
            clean.append((np.round(cosine,4)))
            #clean.append(' '.join(str(np.round(cosine,4))))
            #print("similarity: in new Case n",name, ' is ', cosine) 
        df['Similarity_Index'] = clean
        return df
    
    def maxSimilarityLogic(self, df, inputMod):
        suggestedDF = df.sort_values('Similarity_Index', ascending=False).head(20)
        suggestedDF = suggestedDF[['Id','CASENUMBER', 'DESCRIPTION','cleaned_text','STATUS','Module', 'Similarity_Index' ]]
        i = -1
        max_sim = 1
        for item in suggestedDF.Module:
            i += 1
            if len(inputMod) > 0:
                if inputMod[0] in item:
                    max_sim = suggestedDF.iloc[i]['Similarity_Index']
                    break
        adjusted_param1 = (1-max_sim)*.7
        #print(adjusted_param1)
        adjusted_param2 = (1-max_sim)*.4
        #print(adjusted_param2)
        suggestedDF = suggestedDF.reset_index()
        i = -1
        for item in suggestedDF.Module:
            i += 1
            if len(inputMod) > 0:
                if inputMod[0] in item:
                    suggestedDF.at[i,'Similarity_Index'] = suggestedDF.at[i,'Similarity_Index']+ adjusted_param1
                else:
                    suggestedDF.at[i,'Similarity_Index'] = suggestedDF.at[i,'Similarity_Index']+ adjusted_param2
        suggestedDF = suggestedDF.sort_values('Similarity_Index', ascending=False).head(20)
        df4 = suggestedOwner(suggestedDF)
        df5 = df4.to_json(orient='records')
        suggestedDF['json']= ''
        suggestedDF['json'][0] = df5
        suggestedDF = suggestedDF.sort_values('Similarity_Index', ascending=False).head(5)
        return suggestedDF

    def suggestedOwner(self, suggestedDF):
        t1 = suggestedDF.Case_Owner.value_counts()
        t2 = t1.to_dict()
        df2 = pd.DataFrame.from_dict(t2,orient='index', columns=["Case_Count"])
        avg_counts = []
        for item in t2:
            loc_avg = 0
            loc_avg = suggestedDF[suggestedDF['Case_Owner'] == item]['Case_AGE_IN_DAYS__C'].mean()
            avg_counts.append(loc_avg)
        print('average --> ', loc_avg)
        df2['Avg_Days'] = avg_counts
        df3 = df2.sort_values('Avg_Days', ascending=True).head(20)
        return df3

class PreProcessing:
    def inputTokenizing(self, input):
        sw = stopwords.words('english') 
        input_token = word_tokenize(input) 
        input_set = {w for w in input_token if not w in sw} 
        return input_set
    
    
    def identifyModule(self, input):
        modules = ['CMDB', 'Console', 'Smart Sync', 'SLA', 'Service Request', 'Request Definition', 'Self Service', 'Pentaho',
          'Template', 'Category', 'Usage Metric', 'SRD', 'Service Target', 'Task', 'Broadcast', 'Change Request', 
          'Incident', 'Approval', 'Lookup', 'CPU Time', 'KA', 'Knowledge Article', 'Workflow', 'DmlException', 'BCM',
          'Integration', 'Activity Feed', 'Smart Suggestion', 'Upgrade', 'REST API', 'Discovery', 'Scheduled Job', 
          'System.LimitException:', 'Tasks Closed Controller', 'Email Listener', 'lightning', 'Delegated Approver', 
          'time based workflow', 'report', 'FIELD_CUSTOM_VALIDATION_EXCEPTION', 'Task Template', 'System.DmlException:',
          'Primary Client','SSO']
        input_mod = set()
        print("input-->",input)
        for item in modules:
            item1 = ' ' +item.lower() + ' '
            sentence1 = input.lower()
            if item1 in sentence1:
                input_mod.add(item)  
        input_mod = list(input_mod)
        print("Module-->", input_mod)
        return input_mod
        
    def preProcessing(self, df):
        #print(df.columns)
        #print(df['Problem_Description_and_Definition__c'])
        modules = ['CMDB', 'Console', 'Smart Sync', 'SLA', 'Service Request', 'Request Definition', 'Self Service', 'Pentaho',
          'Template', 'Category', 'Usage Metric', 'SRD', 'Service Target', 'Task', 'Broadcast', 'Change Request', 
          'Incident', 'Approval', 'Lookup', 'CPU Time', 'KA', 'Knowledge Article', 'Workflow', 'DmlException', 'BCM',
          'Integration', 'Activity Feed', 'Smart Suggestion', 'Upgrade', 'REST API', 'Discovery', 'Scheduled Job', 
          'System.LimitException:', 'Tasks Closed Controller', 'Email Listener', 'lightning', 'Delegated Approver', 
          'time based workflow', 'report', 'FIELD_CUSTOM_VALIDATION_EXCEPTION', 'Task Template', 'System.DmlException:',
          'Primary Client','SSO']           
        stopwords_EN  = set(stopwords.words('english'))
        cleaned_text = []
        clean = []
        url = 'http, www.'
        spl_char = '\', --, -, [, ], \n, (, ), \, ,?' #!"#$%&\'()*+,-./:;<=>?@[\\]^_`{|}~
        module = []
        for sentence in df.DESCRIPTION:
            temp_mod = set()
            #sentence = str(sentence.encode("latin-1"), "windows-1252")
            str2 = re.findall('.*Error:.*',sentence)
            if 'Steps to Reproduce' in sentence:
                sentence = sentence.split('Steps to Reproduce')[0]
            if 'steps to reproduce' in sentence:
                sentence = sentence.split('steps to reproduce')[0]
            if 'Steps to reproduce' in sentence:
                sentence = sentence.split('Steps to reproduce')[0]
            #sentence = sentence.split('Steps to reproduce')[0]
            sentence = sentence.split('Apex Class:')[0]
            sentence = sentence.replace('Remedyforce Version:','')
            sentence = sentence.replace('Summary/Error of issue:','')
            sentence = sentence.replace('\'','')
            sentence = sentence.replace(',','')
            str4 = re.findall('(\w*00D\w*)|(\w*00d\w*)]', sentence)
            #print(str4, 'size ::', len(str4))
            if len(str4) > 0:
                if str4[0][0] == '':
                    sentence = sentence.replace(str4[0][1], '')
                elif str4[0][1] == '':
                    sentence = sentence.replace(str4[0][0], '')
            sentence = sentence + str(str2)
            #cleaned_text = re.sub(r'\d+', '', sentence)
            for item in modules:
                item1 = ' ' +item.lower() + ' '
                sentence1 = sentence.lower()
                if item1 in sentence1:
                    temp_mod.add(item+'$$')
            cleaned_text = [word for word in sentence.split() if word not in punctuation]
            cleaned_text = [word for word in cleaned_text if word not in url]
            cleaned_text = [word for word in cleaned_text if word not in stopwords_EN]
            cleaned_text = [word for word in cleaned_text if word not in spl_char]
            
            module.append(' '.join(temp_mod))
            clean.append(' '.join(cleaned_text))
        Case_Owner = []
        for item in df.Case_Owner__c:
            if item :
                print('item-->', item)
                text = re.findall("_self\">.*</a>.*href", item)
                print('text-->', text)
                text = text[0].replace('_self">','').replace('</a> [<a href','')
                print('text2-->', text)
                Case_Owner.append(text)
        df['Module'] = module
        df['cleaned_text'] = clean
        df['Case_Owner'] = Case_Owner
        df.Module = df.Module.apply(lambda x:x.replace('$$ ',',').replace('$$',''))
        #print("K--->191",df)
        return df
    
class AuthAndRetrieveData:
    def __init__(self, userName, password, token, isSandbox):
        self.userName = userName
        self.password = password
        self.token = token
        if (isSandbox == 'True'):
            self.isSandbox = True 
        else:
            self.isSandbox = False
        self.df = pd.DataFrame()
            
    def authentication(self, data):
        print(self.userName)
        print(self.password)
        print(self.token)
        print(self.isSandbox)
        if(self.token):
            session_id, instance = SalesforceLogin(self.userName, self.password, security_token=self.token, sandbox=self.isSandbox ) 
        else:
            session_id, instance = SalesforceLogin(self.userName, self.password, sandbox=self.isSandbox ) 
        print(instance)
        sf = Salesforce(instance=instance, session_id=session_id)
        print(sf)
        return sf
        
    def retrieveData(self, sf, inputCaseId):
        print(inputCaseId)
        queryCase = sf.bulk.Request_for_Assistance__c.query("Select id, CASENUMBER, STATUS, ORIGIN, SUBJECT, DESCRIPTION, CLOSEDDATE, SLASTARTDATE, SLAEXITDATE, CREATEDDATE, SERVICE_LEVEL__C, SEVERITY__C, CASE_AGGRAVATION__C, SC_LP_VERSION_CODE_HL__C, SLA_EXPIRATION__C, SLA_PRIORITIZATION__C, SC_CASESUMMARY__C, ACCOUNT_NAME__C, CUSTOMER_STATUS_AGE__C, PENDING_CLIENT_CUMULATIVE_TIME__C, PENDING_CUSTOMER_SUPPORT_CUMULATIVE_TIME__C, PENDING_ENGINEERING_CUMULATIVE_TIME__C, SUPPORT_AND_CUSTOMER_HANDOFFS_COUNT__C, SUPPORT_AND_ENGINERERING_HANDOFFS_COUNT__C, CASE_SUMMARY_LAST_UPDATED__C, ACTIVE_GCC__C, SUBMITTED_HOUR_GMT__C from Request_for_Assistance__c where id !='"+ inputCaseId+ "' limit 10000")
        
        ##queryCase = [item.replace("None", "") for item in queryCase]
        print(queryCase)
        return queryCase
    
        
