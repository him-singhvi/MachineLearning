OAUTH_CONFIG = {
    'consumer_key': 'htMmTCvPz9YVMT4YQjDqsGu5x',
    'consumer_secret': '43rReEuLF0FJPPj8NTcbzNrGMaQsSuGGkCsLmjcFxicOlqHOjv',
    'access_token': '126182028-sRDgGaxn4lhyDNBgkMGGJKPs7cHYmuuGxwQJA2yH',
    'access_token_secret': 'QWCsnaXIk3cq8DTLmn55AyPif3zf3OC5SWqQ4Oe2BboQv'
}